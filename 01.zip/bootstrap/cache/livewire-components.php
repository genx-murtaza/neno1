<?php return array (
  'customer-adduser' => 'App\\Http\\Livewire\\CustomerAdduser',
  'customer-master' => 'App\\Http\\Livewire\\CustomerMaster',
);