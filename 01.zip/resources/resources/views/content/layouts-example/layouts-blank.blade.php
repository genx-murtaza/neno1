@extends('layouts/blankLayout')

@section('title', 'Blank layout - Layouts')

@section('content')
<h4 class="fw-bold p-4">Blank Page</h4>
@endsection
