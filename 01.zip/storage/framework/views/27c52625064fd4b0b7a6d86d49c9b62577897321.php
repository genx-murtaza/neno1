<?php if(session()->has('username')): ?>

    

    <?php $__env->startSection('main-section'); ?>

        <!-- Content wrapper -->
        <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Master /</span> User Master</h4>
            <div class= "d-flex justify-content-end mb-2">
                <a href="<?php echo e(url('/usermaster/adduser')); ?>"> <button class="btn btn-primary"> Add User </button> </a>
            </div>

            <!-- Hoverable Table rows -->
            <div class="card">
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th>Status</th>
                    <th>Action</th>

                    

                    </tr>
                </thead>

                <tbody class="table-border-bottom-0">

                    <?php $no=1; ?>
                    <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($value->fullname); ?></td>
                    <td><?php echo e($value->username); ?></td>
                    <td><?php echo e($value->contact); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td>
                        <?php
                            if ($value->level == "1")
                                $levelname = "Admin";
                            elseif ($value->level == "2")
                                $levelname = "Director";
                            elseif ($value->level == "3")
                                $levelname = "Sales";
                            elseif ($value->level == "4")
                                $levelname = "Approval";
                            elseif ($value->level == "5")
                                $levelname = "Only Reports";
                            else
                                $levelname = "Invalid";
                        ?>
                        <?php echo e($levelname); ?>

                    </td>
                    <td>
                        <?php if($value->active): ?>
                            <a title = "Click to In-Active" href="<?php echo e(route('usermaster.changeactive', ['id' => $value->id])); ?>">
                                <span class="badge badge-success"> Active </span>
                            </a>
                        <?php else: ?>
                            <a title = "Click to Active" href="<?php echo e(route('usermaster.changeactive', ['id' => $value->id])); ?>">
                                <span class="badge badge-danger"> In-Active </span>
                            </a>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="dropdown">
                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="bx bx-dots-vertical-rounded"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('usermaster.edituser', ['id' => $value->id])); ?>">
                                <i class="bx bx-edit-alt me-1"></i> Edit
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('usermaster.deleteuser', ['id' => $value->id])); ?>">
                                <i class="bx bx-trash me-1"></i> Delete
                            </a>
                            <a class="dropdown-item" href="<?php echo e(route('usermaster.sendpassword', ['id' => $value->id])); ?>">
                                <i class="bx bx-link me-1"></i> Forget Password
                            </a>
                        </div>
                        </div>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            </div>
            </div>
            <!--/ Hoverable Table rows -->
        </div>

        <!-- / Content -->
        <?php if(Session::has('message')): ?>
            <script> alert("<?php echo e(Session('message')); ?>"); </script>
        <?php endif; ?>

    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php
        header('Location: /');
        die();
    ?>
<?php endif; ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\genx1\resources\views/usermaster.blade.php ENDPATH**/ ?>