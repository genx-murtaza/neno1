<?php if(session()->has('username')): ?>

    

    <?php $__env->startSection('main-section'); ?>

        <!-- Content wrapper -->
        <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Master /</span> Customers</h4>
            <div class= "d-flex justify-content-end mb-2">
                <a href="<?php echo e(url('/customer/adduser')); ?>"> <button class="btn btn-primary"> Add User </button> </a>
            </div>

            <!-- Hoverable Table rows -->
            <div class="card">
            <div class="table-responsive text-nowrap">
                <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>DOB</th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Visits</th>
                    <th>Reference</th>

                    

                    </tr>
                </thead>

                <tbody class="table-border-bottom-0">

                    <?php $no=1; ?>
                    <?php $__currentLoopData = $allcustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($value->cname); ?></td>
                    <td><?php echo e($value->ccontact); ?></td>
                    <td><?php echo e($value->cemail); ?></td>
                    <td><?php echo e($value->cdob); ?></td>
                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            </div>
            </div>
            <!--/ Hoverable Table rows -->
        </div>

        <!-- / Content -->
        <?php if(Session::has('message')): ?>
            <script> alert("<?php echo e(Session('message')); ?>"); </script>
        <?php endif; ?>

    <?php $__env->stopSection(); ?>

<?php else: ?>
    <?php
        header('Location: /');
        die();
    ?>
<?php endif; ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\genx1\resources\views/livewire/customer.blade.php ENDPATH**/ ?>