<html>
    <head>
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\genx1\resources\views/layouts/app.blade.php ENDPATH**/ ?>