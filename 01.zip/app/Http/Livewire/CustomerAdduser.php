<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CustomerAdduser extends Component
{
    public function render()
    {
        return view('livewire.customer-adduser');
    }
}
